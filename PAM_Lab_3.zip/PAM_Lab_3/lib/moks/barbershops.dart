import 'package:lab_3/models/barbershop.dart';

List<Barbershop> barbershops = [
  Barbershop("Twinsky Monkey Barber & Men Stuff", "London", 4.3, "assets/images/barbershops/barbershop_1.jpg"),
  Barbershop("Gentleman Groomers", "New York", 3.8, "assets/images/barbershops/barbershop_2.webp"),
  Barbershop("Royal Shave and Cuts", "Los Angeles", 4.5, "assets/images/barbershops/barbershop_3.jpg"),
  Barbershop("Classic Cuts Barbershop", "Chicago", 4.1, "assets/images/barbershops/barbershop_4.jpg"),
  Barbershop("The Urban Barber", "Houston", 4.0, "assets/images/barbershops/barbershop_5.jpg"),
  // Barbershop("Sharp Scissors & Blades", "Miami", 4.7, "assets/images/barbershop_6.jpg"),
  // Barbershop("The Gents Parlor", "San Francisco", 3.9, "assets/images/barbershop_7.jpg"),
  // Barbershop("Modern Men’s Grooming", "Austin", 4.4, "assets/images/barbershop_8.jpg"),
  // Barbershop("Refined Razor Cuts", "Boston", 4.2, "assets/images/barbershop_9.jpg"),
  // Barbershop("King’s Crown Barbers", "Seattle", 4.6, "assets/images/barbershop_10.jpg"),
];