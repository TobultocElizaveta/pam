import '../models/user.dart';

List<User> users = [
  User("Joe Samanta", "Yogyakarta", "assets/images/avatars/5.webp")
];