// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'banner.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Banner _$BannerFromJson(Map<String, dynamic> json) => Banner()
  ..image = json['image'] as String?
  ..buttonTitle = json['button_title'] as String?;

Map<String, dynamic> _$BannerToJson(Banner instance) => <String, dynamic>{
      'image': instance.image,
      'button_title': instance.buttonTitle,
    };
