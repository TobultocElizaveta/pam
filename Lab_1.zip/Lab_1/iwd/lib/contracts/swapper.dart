abstract class CCSwapper{
  void swap();
}