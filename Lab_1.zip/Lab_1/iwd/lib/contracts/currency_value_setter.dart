abstract class CCValueSetter {
  void setValue(double value);
}